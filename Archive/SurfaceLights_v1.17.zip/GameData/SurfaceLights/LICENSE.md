# Surface Mounted Stock-Alike Lights for Self-Illumination

Author: [Why485](http://forum.kerbalspaceprogram.com/index.php?/profile/26795-why485/)

Maintainer: igor.zavoychinskiy@gmail.com

GitHub: https://github.com/ihsoft/SurfaceLights

* * *

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International Public License.

[Legal Code](http://creativecommons.org/licenses/by-nc-sa/4.0/)
