=================================================
Surface Mounted Lights by Why485
=================================================

Self-illumination is something that I find lacking in stock Kerbal Space Program. 
I find the stock lights to be too large and clumsy to use for simple self-lighting. 
The landing light especially is just overkill for something as simple making sure 
your ship isn't completely dark at night.

To solve this, I made three small lights with a simple stock-alike design. Two of
the lights are loosely based off unreleased parts by ClairaLyrae for KSPX.

BY DEFAULT, KSP ALLOWS ONLY 8 SIMULTANEOUS LIGHT SOURCES. IF SOME OF YOUR LIGHTS
AREN'T SHOWING UP, YOU MAY BE HITTING THE LIGHT SOURCE LIMIT AND SHOULD RAISE IT.

Thanks to peteletroll for maintaining the mod with minor fixes and optimizations.

=================================================
Installation
=================================================

Extract the Gamedata folder into your KSP directory. The Source folder can be safely
disregarded unless you're into that kind of thing.

=================================================
How to Use
=================================================

The three lights function the same as any other lights in the game, except that they
have a default value that is no longer pure white.

Be wary of the per pixel light setting as it may prevent lights from showing. Be aware
that the 4-way light counts as 4 separate lights, even though it is only one part.

=================================================
Changelog
=================================================

1.2.2
- Fixed bug where light color was not correctly restored when loading a ship in the editor.
- Refactored code for expansion (future development of navlights)

1.2.1
- Removed extraneous debug log text

1.2
- Lights now use a custom light module called SurfaceLight
- The surface lights now default to a color set in the parts file
- The color of the light on the model now chanegs to reflect the light's color

1.1 (by peteletroll)
- Lower part temperature tolerance to match the stock lights
- Converted textures to DDS and lowered their size to make them more efficient

1.0
- Initial release

=================================================
License
=================================================

This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International Public License.
http://creativecommons.org/licenses/by-nc-sa/4.0/

